package com.birdlink.collector;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
