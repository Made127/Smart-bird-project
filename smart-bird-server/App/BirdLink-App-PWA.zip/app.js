const state = {
  productId: "BIRD-PLANT-001",
  wifiConnected: true,
  ssid: "Office-WiFi",
  battery: 76,
  charging: false,
  mode: "normal",
  probeConnected: true,
  muted: false,
  volume: 62,
  light: "connected",
  autoCollect: true,
  dndStart: "22:00",
  dndEnd: "08:00",
  lastSync: new Date(),
  sensors: {
    ion: { label: "土壤电离度", value: 1.8, unit: "mS/cm", range: "0.8 - 2.4", status: "good", note: "养分溶解状态正常" },
    nitrogen: { label: "氮含量", value: 42, unit: "mg/kg", range: "30 - 80", status: "good", note: "满足常规绿植需求" },
    phosphorus: { label: "磷含量", value: 18, unit: "mg/kg", range: "12 - 35", status: "good", note: "根系生长条件稳定" },
    potassium: { label: "钾含量", value: 58, unit: "mg/kg", range: "35 - 90", status: "good", note: "抗逆性指标良好" },
    ph: { label: "土壤酸碱度", value: 6.6, unit: "pH", range: "6.0 - 7.2", status: "good", note: "接近中性偏弱酸" },
    moisture: { label: "土壤湿度", value: 48, unit: "%", range: "35 - 65", status: "good", note: "暂不需要浇水" },
    temp: { label: "土壤温度", value: 23.8, unit: "°C", range: "18 - 28", status: "good", note: "适合室内盆栽" },
    light: { label: "光照", value: 426, unit: "lx", range: "300 - 900", status: "good", note: "随土壤数据一起上传" },
    human: { label: "人体感应", value: "未触发", unit: "", range: "触发/未触发", status: "good", note: "感应到时上传“人来了”指令" }
  },
  history: [],
  events: [],
  voices: [],
  alerts: []
};

const metricKeys = ["moisture", "temp", "ph", "light"];
const sections = {
  dashboard: "设备总览",
  network: "WiFi 配网",
  sensors: "传感器采集",
  voice: "语音与对话",
  control: "设备控制",
  alerts: "告警与提醒",
  device: "设备信息"
};

function $(selector) {
  return document.querySelector(selector);
}

function $all(selector) {
  return Array.from(document.querySelectorAll(selector));
}

function nowText(date = new Date()) {
  return date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
}

function randomBetween(min, max, digits = 0) {
  const value = min + Math.random() * (max - min);
  return Number(value.toFixed(digits));
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2300);
}

function addEvent(title, detail) {
  state.events.unshift({ title, detail, time: new Date() });
  state.events = state.events.slice(0, 8);
  renderEvents();
}

function addAlert(title, detail, level = "medium") {
  state.alerts.unshift({ title, detail, level, time: new Date(), handled: false });
  renderAlerts();
}

function addCommand(name, detail) {
  $("#commandStatus").textContent = "已下发";
  addEvent(name, detail);
  showToast(detail);
  setTimeout(() => {
    $("#commandStatus").textContent = "待命";
  }, 1400);
}

function seedHistory() {
  const base = new Date();
  state.history = Array.from({ length: 12 }).map((_, index) => {
    const time = new Date(base.getTime() - (11 - index) * 2 * 60 * 60 * 1000);
    return {
      time,
      moisture: randomBetween(39, 57),
      temp: randomBetween(21, 25, 1),
      ph: randomBetween(6.2, 6.9, 1),
      light: randomBetween(320, 760)
    };
  });
}

function collectSensors(reason = "手动触发") {
  if (!state.probeConnected) {
    addAlert("土壤探针未连接", "磁吸接口已断开，主控已停止土壤信号采集。", "high");
    showToast("探针未连接，无法采集土壤数据");
    return;
  }

  state.sensors.ion.value = randomBetween(1.1, 2.3, 1);
  state.sensors.nitrogen.value = randomBetween(32, 72);
  state.sensors.phosphorus.value = randomBetween(14, 32);
  state.sensors.potassium.value = randomBetween(42, 86);
  state.sensors.ph.value = randomBetween(6.1, 7.1, 1);
  state.sensors.moisture.value = randomBetween(32, 68);
  state.sensors.temp.value = randomBetween(20.5, 27.5, 1);
  state.sensors.light.value = randomBetween(260, 980);
  state.sensors.human.value = "未触发";

  updateSensorHealth();
  state.lastSync = new Date();
  state.history.push({
    time: new Date(),
    moisture: state.sensors.moisture.value,
    temp: state.sensors.temp.value,
    ph: state.sensors.ph.value,
    light: state.sensors.light.value
  });
  state.history = state.history.slice(-18);

  addEvent("完成一次采集", `${reason}，数据已加入待上传内容。`);
  renderAll();
}

function updateSensorHealth() {
  const moisture = state.sensors.moisture;
  moisture.status = moisture.value < 35 || moisture.value > 65 ? "watch" : "good";
  moisture.note = moisture.value < 35 ? "土壤偏干，建议提醒浇水" : moisture.value > 65 ? "土壤偏湿，注意通风" : "暂不需要浇水";
  if (moisture.status === "watch") {
    addAlert("土壤湿度异常", `${moisture.label} 当前 ${moisture.value}${moisture.unit}。`, "medium");
  }

  const ph = state.sensors.ph;
  ph.status = ph.value < 6 || ph.value > 7.2 ? "watch" : "good";
  ph.note = ph.status === "good" ? "接近中性偏弱酸" : "酸碱度偏离建议范围";

  const light = state.sensors.light;
  light.status = light.value < 300 ? "watch" : light.value > 900 ? "watch" : "good";
  light.note = light.value < 300 ? "光照偏低，可调整摆放位置" : light.value > 900 ? "光照较强，注意叶片状态" : "随土壤数据一起上传";
}

function renderStatus() {
  $("#productId").textContent = state.productId;
  $("#wifiStatus").textContent = state.wifiConnected ? "已连接" : "未连接";
  $("#batteryText").textContent = `${state.battery}%${state.charging ? " 充电中" : ""}`;
  $("#modeText").textContent = state.mode === "sleep" ? "休眠" : state.mode === "dnd" ? "勿扰" : "正常";
  $("#probeText").textContent = state.probeConnected ? "已连接" : "已断开";
  $("#sideOnline").textContent = state.wifiConnected ? "设备在线" : "设备离线";
  $("#sideLastSync").textContent = `${nowText(state.lastSync)} 同步`;
  $(".signal-dot").classList.toggle("online", state.wifiConnected);
  $(".signal-dot").classList.toggle("offline", !state.wifiConnected);

  const summary = state.wifiConnected
    ? `WiFi 已连接，土壤传感器${state.probeConnected ? "在线" : "断开"}，下一次自动采集将在 01:42 后执行。`
    : "WiFi 未连接，设备进入本地等待状态，请重新配网。";
  $("#deviceSummary").textContent = summary;

  $("#sleepToggle").checked = state.mode === "sleep";
  $("#dndToggle").checked = state.mode === "dnd";
  $("#autoCollectToggle").checked = state.autoCollect;
  $("#volumeRange").value = state.volume;
  $("#volumeValue").textContent = state.volume;
  $("#muteBadge").textContent = state.muted ? "已静音" : "未静音";
  $("#probeToggleBtn").textContent = state.probeConnected ? "断开土壤探针" : "连接土壤探针";
  $("#lightText").textContent = lightLabel(state.light);

  const birdLight = $("#birdLight");
  birdLight.className = "bird-light";
  if (state.light === "charging" || state.light === "low") birdLight.classList.add("amber");
  if (state.light === "pairing" || state.light === "charging") birdLight.classList.add("pulse");
}

function lightLabel(light) {
  return {
    connected: "蓝色长亮",
    pairing: "蓝色呼吸",
    charging: "橙黄呼吸",
    low: "橙黄告警"
  }[light] || "蓝色长亮";
}

function renderMetrics() {
  const grid = $("#metricGrid");
  grid.innerHTML = metricKeys.map((key) => {
    const item = state.sensors[key];
    return `
      <article class="metric-card ${item.status}">
        <h3>${item.label}</h3>
        <div class="metric-value">${item.value}${item.unit}</div>
        <div class="metric-foot">
          <span>${item.range}</span>
          <strong>${statusLabel(item.status)}</strong>
        </div>
      </article>
    `;
  }).join("");
}

function statusLabel(status) {
  return status === "good" ? "正常" : status === "watch" ? "关注" : "异常";
}

function renderSensorTable() {
  const rows = Object.values(state.sensors).map((item) => `
    <tr>
      <td>${item.label}</td>
      <td><strong>${item.value}${item.unit}</strong></td>
      <td>${item.range}</td>
      <td><span class="badge ${item.status}">${statusLabel(item.status)}</span></td>
      <td>${item.note}</td>
    </tr>
  `);
  $("#sensorTable").innerHTML = rows.join("");
}

function renderTrend() {
  const canvas = $("#trendCanvas");
  const ctx = canvas.getContext("2d");
  const key = $("#trendSelect").value;
  const data = state.history.map((point) => point[key]);
  const labels = state.history.map((point) => nowText(point.time));
  const width = canvas.width;
  const height = canvas.height;
  const pad = 36;
  const min = Math.min(...data) - 2;
  const max = Math.max(...data) + 2;
  const colors = { moisture: "#2f8f5b", temp: "#c77b18", ph: "#6e5ab8", light: "#237c9d" };

  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#fbfcfb";
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = "#dfe6df";
  ctx.lineWidth = 1;

  for (let i = 0; i < 4; i += 1) {
    const y = pad + i * ((height - pad * 2) / 3);
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(width - pad, y);
    ctx.stroke();
  }

  const xFor = (index) => pad + index * ((width - pad * 2) / Math.max(1, data.length - 1));
  const yFor = (value) => height - pad - ((value - min) / Math.max(1, max - min)) * (height - pad * 2);

  ctx.beginPath();
  data.forEach((value, index) => {
    const x = xFor(index);
    const y = yFor(value);
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = colors[key];
  ctx.lineWidth = 3;
  ctx.stroke();

  data.forEach((value, index) => {
    const x = xFor(index);
    const y = yFor(value);
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fillStyle = colors[key];
    ctx.fill();
  });

  ctx.fillStyle = "#66736c";
  ctx.font = "12px Microsoft YaHei, Arial";
  ctx.fillText(`${Math.round(max)}`, 8, pad + 4);
  ctx.fillText(`${Math.round(min)}`, 8, height - pad + 4);
  ctx.fillText(labels[0] || "", pad, height - 10);
  ctx.textAlign = "right";
  ctx.fillText(labels[labels.length - 1] || "", width - pad, height - 10);
  ctx.textAlign = "left";
}

function renderEvents() {
  const list = $("#eventList");
  if (!state.events.length) {
    list.innerHTML = `<li><strong>暂无事件</strong><time>等待设备上报</time></li>`;
    return;
  }
  list.innerHTML = state.events.map((event) => `
    <li>
      <strong>${event.title}</strong>
      <div>${event.detail}</div>
      <time>${nowText(event.time)}</time>
    </li>
  `).join("");
}

function renderVoices() {
  const list = $("#voiceList");
  if (!state.voices.length) {
    list.innerHTML = `<li><strong>暂无语音记录</strong><div>设备上传语音后会显示在这里。</div><time>等待上传</time></li>`;
    return;
  }
  list.innerHTML = state.voices.map((voice) => `
    <li>
      <strong>${voice.title}</strong>
      <div>${voice.detail}</div>
      <time>${nowText(voice.time)}</time>
    </li>
  `).join("");
}

function renderAlerts() {
  const list = $("#alertList");
  if (!state.alerts.length) {
    list.innerHTML = `<div class="alert-item"><span class="alert-level"></span><div><h3>暂无未处理告警</h3><time>设备运行正常</time></div><span class="badge good">正常</span></div>`;
    return;
  }
  list.innerHTML = state.alerts.map((alert, index) => `
    <article class="alert-item">
      <span class="alert-level ${alert.level === "high" ? "high" : ""}"></span>
      <div>
        <h3>${alert.title}</h3>
        <div>${alert.detail}</div>
        <time>${nowText(alert.time)}</time>
      </div>
      <button class="text-btn" data-alert="${index}" type="button">处理</button>
    </article>
  `).join("");
}

function renderConnection() {
  const stateBox = $("#connectionState");
  const title = state.wifiConnected ? "已连接" : "未连接";
  const detail = state.wifiConnected
    ? `设备当前连接到 ${state.ssid}，信号强度良好。`
    : "设备未连入 WiFi，请重新写入网络信息。";
  stateBox.innerHTML = `
    <span class="large-dot ${state.wifiConnected ? "online" : "offline"}"></span>
    <h3>${title}</h3>
    <p>${detail}</p>
  `;
  $("#networkTime").textContent = state.wifiConnected ? `今天 ${nowText(state.lastSync)}` : "未连接";
}

function renderAll() {
  renderStatus();
  renderMetrics();
  renderSensorTable();
  renderTrend();
  renderEvents();
  renderVoices();
  renderAlerts();
  renderConnection();
}

function bindNavigation() {
  $all(".nav-item").forEach((button) => {
    button.addEventListener("click", () => {
      const section = button.dataset.section;
      $all(".nav-item").forEach((item) => item.classList.remove("is-active"));
      button.classList.add("is-active");
      $all(".section").forEach((item) => item.classList.toggle("is-active", item.id === section));
      $("#pageTitle").textContent = sections[section];
      if (section === "dashboard") renderTrend();
    });
  });
}

function bindControls() {
  $("#refreshBtn").addEventListener("click", () => collectSensors("顶部按钮触发"));
  $("#collectBtn").addEventListener("click", () => collectSensors("传感器页触发"));
  $("#sendAllBtn").addEventListener("click", () => {
    state.lastSync = new Date();
    addCommand("同步到服务器", "上传产品 ID、传感器数据和语音队列。");
    renderAll();
  });
  $("#clearEventsBtn").addEventListener("click", () => {
    state.events = [];
    renderEvents();
  });
  $("#trendSelect").addEventListener("change", renderTrend);

  $all(".action-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const command = button.dataset.command;
      if (command === "collect") collectSensors("快捷控制触发");
      if (command === "sleep") setMode(state.mode === "sleep" ? "normal" : "sleep");
      if (command === "dnd") setMode(state.mode === "dnd" ? "normal" : "dnd");
      if (command === "mute") {
        state.muted = !state.muted;
        addCommand(state.muted ? "开启静音" : "取消静音", "硬件层面的静音状态已更新。");
        renderAll();
      }
    });
  });

  $("#wifiForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const ssid = $("#ssidInput").value.trim();
    const password = $("#passwordInput").value.trim();
    if (!ssid || password.length < 8) {
      showToast("请填写 WiFi 名称，并保证密码至少 8 位");
      return;
    }
    state.ssid = ssid;
    state.wifiConnected = true;
    state.lastSync = new Date();
    $("#connectTime").textContent = `${randomBetween(1.2, 3.6, 1)}s`;
    $("#ipText").textContent = `192.168.31.${randomBetween(20, 230)}`;
    addEvent("WiFi 配网成功", `设备已连接到 ${ssid}。`);
    renderAll();
  });

  $("#simulateHumanBtn").addEventListener("click", () => {
    state.sensors.human.value = "已触发";
    state.sensors.human.status = "watch";
    addEvent("人体感应触发", "设备上传“人来了”指令。");
    addAlert("人体感应事件", "检测到有人靠近设备。", "medium");
    renderAll();
  });

  $("#autoCollectToggle").addEventListener("change", (event) => {
    state.autoCollect = event.target.checked;
    addCommand("自动采集设置", state.autoCollect ? "已开启每 2 小时采集一次。" : "已关闭自动采集。");
  });

  $("#volumeRange").addEventListener("input", (event) => {
    state.volume = Number(event.target.value);
    $("#volumeValue").textContent = state.volume;
  });
  $("#volumeRange").addEventListener("change", () => {
    addCommand("音量调节", `默认音量已设置为 ${state.volume}。`);
  });

  $("#uploadVoiceBtn").addEventListener("click", () => {
    state.voices.unshift({
      title: "用户语音已上传",
      detail: "停顿 500ms 后上传，服务器返回一段播放语音和状态查询指令。",
      time: new Date()
    });
    addEvent("语音交互", "服务器返回语音 + 指令。");
    renderAll();
  });

  $("#sleepToggle").addEventListener("change", (event) => {
    setMode(event.target.checked ? "sleep" : "normal");
  });
  $("#dndToggle").addEventListener("change", (event) => {
    setMode(event.target.checked ? "dnd" : "normal");
  });
  $("#dndStart").addEventListener("change", (event) => {
    state.dndStart = event.target.value;
    addCommand("勿扰时间更新", `开始时间 ${state.dndStart}。`);
  });
  $("#dndEnd").addEventListener("change", (event) => {
    state.dndEnd = event.target.value;
    addCommand("勿扰时间更新", `结束时间 ${state.dndEnd}。`);
  });

  $all(".light-chip").forEach((button) => {
    button.addEventListener("click", () => {
      $all(".light-chip").forEach((item) => item.classList.remove("is-selected"));
      button.classList.add("is-selected");
      state.light = button.dataset.light;
      addCommand("状态灯切换", `当前灯光状态为 ${lightLabel(state.light)}。`);
      renderAll();
    });
  });

  $("#probeToggleBtn").addEventListener("click", () => {
    state.probeConnected = !state.probeConnected;
    if (!state.probeConnected) {
      addAlert("土壤传感器断开", "4P 磁吸接口分离，主控已下发停止采集指令。", "high");
    }
    addCommand("探针连接状态", state.probeConnected ? "土壤探针已连接。" : "土壤探针已断开。");
    renderAll();
  });

  $("#rebootBtn").addEventListener("click", () => {
    state.light = "pairing";
    addCommand("设备重启", "设备进入初始化，状态灯蓝色呼吸。");
    renderAll();
  });

  $("#factoryBtn").addEventListener("click", () => {
    state.volume = 62;
    state.muted = false;
    state.mode = "normal";
    state.light = "connected";
    addCommand("恢复默认配置", "默认音量、模式和灯光状态已恢复。");
    renderAll();
  });

  $("#lowBatteryBtn").addEventListener("click", () => {
    state.battery = 5;
    state.light = "low";
    addAlert("电量低于 5%", "设备应显示橙黄色低电量灯，并提醒尽快充电。", "high");
    renderAll();
  });

  $("#wifiDropBtn").addEventListener("click", () => {
    state.wifiConnected = false;
    state.light = "pairing";
    addAlert("WiFi 已断开", "设备显示蓝色呼吸灯，请检查网络或重新配网。", "high");
    renderAll();
  });

  $("#clearAlertsBtn").addEventListener("click", () => {
    state.alerts = [];
    renderAlerts();
    showToast("告警已全部处理");
  });

  $("#alertList").addEventListener("click", (event) => {
    const button = event.target.closest("[data-alert]");
    if (!button) return;
    state.alerts.splice(Number(button.dataset.alert), 1);
    renderAlerts();
  });
}

function setMode(mode) {
  state.mode = mode;
  if (mode === "sleep") {
    addCommand("进入休眠", "小鸟不主动说话，麦克风保持开启。");
  } else if (mode === "dnd") {
    addCommand("进入勿扰", `WiFi 暂停传输，定时 ${state.dndStart} - ${state.dndEnd}。`);
  } else {
    addCommand("恢复正常", "设备恢复主动交互与数据传输。");
  }
  renderAll();
}

function init() {
  seedHistory();
  state.events = [
    { title: "设备上线", detail: "ESP32 已连接 WiFi，等待服务器指令。", time: new Date(Date.now() - 8 * 60 * 1000) },
    { title: "自动采集", detail: "按 2 小时间隔上传土壤与光照数据。", time: new Date(Date.now() - 42 * 60 * 1000) }
  ];
  state.voices = [
    { title: "服务器语音播放", detail: "已向设备下发一段问候语音。", time: new Date(Date.now() - 18 * 60 * 1000) }
  ];
  bindNavigation();
  bindControls();
  renderAll();
}

init();

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  navigator.serviceWorker.register("./service-worker.js").catch(() => {});
}
